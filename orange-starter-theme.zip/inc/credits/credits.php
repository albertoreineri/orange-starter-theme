<div class="col-12 text-center">
    Realizzato da <a href="http://albertoreineri.it" target="_blank" title="Alberto Reineri Web designer & developer Cuneo">Alberto Reineri</a>
</div>