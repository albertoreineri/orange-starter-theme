<?php
get_header();
?>

<h1>Errore 404</h1>

La pagina non è stata trovata <br>
Torna alla <a href="<?php echo esc_url(home_url('/')); ?>">home</a>

<?php
get_footer();
?>