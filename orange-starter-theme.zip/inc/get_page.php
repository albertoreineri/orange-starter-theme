
<!-- Titolo -->
<h1><?php the_title(); ?></h1>
<!-- /Titolo -->

<!-- Immagine -->
<?php the_post_thumbnail('banner-image'); ?>
<!-- /Immagine -->

<!-- Contenuto -->
<?php the_content(); ?>
<!-- /Contenuto -->
